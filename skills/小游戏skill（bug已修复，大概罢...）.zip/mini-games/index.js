// 群内小游戏：LLM 型技能（注册工具）+ 三个钩子（局面注入 / 泄漏守卫两层）。
//
// ── 为什么是"技能 + 钩子" ──
//   · 工具：模型要听懂「来玩猜数字」「我猜 50」「不玩了」→ 只有注册工具这条路。
//   · 钩子：局面不能靠模型记。它每轮都是全新的，上一轮说过"范围收窄到 30~70"这一轮就忘了。
//     所以由插件把当前局面**确定性地**塞进提示词（一行，见 engine.hintLine）。
//   钩子硬约束（文档 §3.2）：单 Skill 5 秒超时、不许发网络、不许发消息 → 只读一次本地存档（带缓存）。
//
// ── 省 token 的三条纪律（2026-09-22 实测后定的）──
//   ① **工具描述要短**：schema 每次请求都带（旧版 5 个工具 1568 字）。现在 4 个工具、
//      只说"什么时候用"；玩法细节全放 skill.json 的静态片段（那份跨运行缓存，近乎免费）。
//   ② **每轮只注入一行局面**：注入不进前缀缓存，所以按字抠；规则不进注入。
//   ③ **群聊里只发群友该看的话**：内部指令发进群既贵（永久留在聊天记录里、每轮重新计费）
//      又会把模型教坏（它照着抄）。say / forModel 必须分开，见 engine.js 顶部注释。
//
// ── 兼容性 ──
//   只用 node 内置模块 + `../../src/config.js` 的 DATA_DIR（与 plugins/life-system 同一做法）。
//   src/config.js 与 0.4 版逐字节一致（SHA256 相同），所以这个包直接放进 0.4 的 skills/ 也能跑。
import { DATA_DIR } from '../../src/config.js';
import {
  loadGames, listGames, startGame, moveGame, stopGame, revealGame, spoilerOf, hintLine, looksLikeOwnOutput
} from './lib/engine.js';
import { leakedChunk, stripSecret } from './lib/leak.js';

/** 注入块的起止标记（同一行内，便于整行替换）。 */
const MARK = '⟦小游戏⟧';

let cfg = () => ({});
let log = () => {};

export function setup(api) {
  cfg = api.config;
  log = api.log || (() => {});
  log('群内小游戏已加载');

  const guard = () => (cfg().enabled === false ? '小游戏被管理员关掉了（设置 → 技能 → 群内小游戏）。' : '');

  // ── 开一局 ──
  api.registerTool({
    id: 'game_start',
    name: '开小游戏',
    description: '在群里开一局小游戏。game 填游戏名（清单见系统提示）或「随机」；'
      + '已经有一局时会被拒，除非 force=true。海龟汤可以自带 puzzle/solution 自己出题。',
    category: 'utility',
    icon: '🎮',
    parameters: {
      type: 'object',
      properties: {
        game: { type: 'string', description: '游戏名，或「随机」' },
        force: { type: 'boolean', description: '已有牌局时是否顶掉重开' },
        puzzle: { type: 'string', description: '仅海龟汤自定义题：汤面' },
        solution: { type: 'string', description: '仅海龟汤自定义题：汤底（绝不能说出去）' },
        title: { type: 'string', description: '仅海龟汤自定义题：小标题' }
      },
      required: ['game']
    },
    async execute(ctx, args) {
      const bad = guard();
      if (bad) return { content: bad, isError: true };
      await loadGames();
      const r = startGame(cfg(), ctx.chatKey, {
        game: args?.game,
        player: playerOf(ctx, String(args?.game || '')),
        force: args?.force === true,
        ctx,
        ...({ puzzle: args?.puzzle, solution: args?.solution, title: args?.title })
      });
      if (!r.ok) return { content: r.say, isError: true };
      const sent = await say(ctx, r.say);
      const head = sent
        ? `开场白已经发出去了（「${String(r.say).slice(0, 40)}」），不要再复述一遍。`
        : `要说的话：${r.say}`;
      return { content: `${head}${r.forModel ? `\n${r.forModel}` : ''}${line(ctx)}` };
    }
  });

  // ── 玩家动作 ──
  api.registerTool({
    id: 'game_move',
    name: '玩家出了一步',
    description: '把群友这一步的**原话**交给插件判定（猜的数、掷、接龙、出拳、落子、提问…）。'
      + '不要自己判对错、不要自己算结果，判定结果会告诉你。',
    category: 'utility',
    icon: '🎯',
    parameters: {
      type: 'object',
      properties: { text: { type: 'string', description: '玩家这一步的原话，例如「我猜 50」' } },
      required: ['text']
    },
    async execute(ctx, args) {
      const bad = guard();
      if (bad) return { content: bad, isError: true };
      await loadGames();
      const text = String(args?.text || '').trim();
      const r = moveGame(cfg(), ctx.chatKey, { text, player: playerOf(ctx, text), ctx });
      if (!r.ok) return { content: r.forModel, isError: true };
      const sent = await say(ctx, r.say);
      const tail = r.over
        ? '（这局结束了，结果已经发出去；要不要补一句话由你决定，但不要再复述数字/结果。）'
        : (sent ? '（已经发出去了。没有别的话要说就结束这一轮，别再复述结果。）' : '');
      return { content: `${r.forModel}${tail ? `\n${tail}` : ''}${line(ctx)}` };
    }
  });

  // ── 揭晓（海龟汤）──
  api.registerTool({
    id: 'game_reveal',
    name: '揭晓答案',
    description: '海龟汤专用：玩家把汤底猜通了，或群友说「公布答案」时用。答案由插件原样发出，你不要复述。',
    category: 'utility',
    icon: '🥣',
    parameters: { type: 'object', properties: {} },
    async execute(ctx) {
      await loadGames();
      const r = revealGame(cfg(), ctx.chatKey);
      if (!r.ok) return { content: r.say, isError: true };
      const sent = await say(ctx, r.say);
      return {
        content: sent
          ? '答案已经原样发出去了，不要再复述、不要补充。'
          : `要说的话（原样发出去，别改内容）：\n${r.say}`
      };
    }
  });

  // ── 收摊 ──
  api.registerTool({
    id: 'game_stop',
    name: '结束小游戏',
    description: '结束当前这局（群友说「不玩了」「结束吧」，或已经分出结果时）。'
      + 'reveal=true 时先把答案公布出来（海龟汤用）。',
    category: 'utility',
    icon: '🛑',
    parameters: {
      type: 'object',
      properties: {
        reason: { type: 'string', description: '为什么结束（可省）' },
        reveal: { type: 'boolean', description: '收摊前先公布答案' }
      }
    },
    async execute(ctx, args) {
      await loadGames();
      const r = stopGame(cfg(), ctx.chatKey, { reason: String(args?.reason || ''), reveal: args?.reveal === true });
      if (!r.ok) return { content: r.say };
      const sent = await say(ctx, r.say);
      return { content: sent ? '收摊的话已经发出去了。' : `要说的话（原样发出去）：${r.say}` };
    }
  });
}

// ── 钩子 ──
//
//   ① before-llm-messages：把当前局面**确定性地**塞进提示词（一行：先删旧的、再追加新的）
//   ② before-tool：海龟汤泄漏守卫 L1（模型把汤底原文塞进 send_* 参数 → 拦下这次调用）
//   ③ after-response：守卫 L2（模型把汤底写进**正文** → 在源头抹掉）
//
// 为什么需要 L2：本项目允许"模型只写了正文、没调工具"时由核心**补发**这条正文
// （orchestrator 的 textOnlySalvage 是直接 executeTool('send_message')，不经过 before-tool）。
// 在 after-response 里改 response.message.content —— 它在这之后才被读取，
// 改完无论原生 tool_calls、正文补发，还是"文本形式的工具调用"解析，拿到的都是干净文本。
export const hooks = {
  'before-llm-messages': ({ messages, chatKey }) => {
    if (cfg().enabled === false) return;
    stripInjection(messages);                    // 先删掉上一轮注入的那一行（否则上下文里越堆越多）
    const line = hintLine(cfg(), chatKey);
    if (!line) return;
    appendToLastUser(messages, line);
  },

  'before-tool': ({ toolName, argsRaw, chatKey }) => {
    if (cfg().enabled === false) return;
    // 小游戏自己的工具不查：game_start 带 solution 是合法开局参数；
    // game_move 的 text 是玩家原话（玩家自己猜中汤底正是这个游戏的目的）。
    if (String(toolName || '').startsWith('mini-games__')) return;
    const secret = spoilerOf(cfg(), chatKey);
    if (!secret) return;
    const chunk = leakedChunk(String(argsRaw || ''), secret);
    if (!chunk) return;
    return {
      block: true,
      reason: `【泄漏拦截】这次 ${toolName} 的内容里有 ${chunk.length} 个字是海龟汤的汤底原文，不能发。`
        + '你只能回「是 / 不是 / 无关 / 部分是」四个词之一，不解释、不举例、不暗示。'
        + '如果玩家已经猜通整个汤底，改调 game_reveal 揭晓（答案由插件原样发出）。'
    };
  },

  'after-response': ({ response, chatKey }) => {
    if (cfg().enabled === false) return;
    const secret = spoilerOf(cfg(), chatKey);
    if (!secret) return;
    const hits = redactSecret(response, secret);
    if (hits) log(`海龟汤：模型正文里抄了汤底原文，已在发送前抹掉（${hits} 处）`);
  }
};

/** 加载时预热一次游戏注册表（钩子要同步读它）。 */
export async function activate() {
  try { await loadGames(); } catch { /* 单个游戏坏了不影响别的 */ }
}

// ── 内部工具 ──

/** 工具返回里补一行当前局面（没有牌局就是空串）。 */
function line(ctx) {
  try {
    const l = hintLine(cfg(), ctx.chatKey);
    return l ? `\n${l}` : '';
  } catch { return ''; }
}

/**
 * 这一步是谁做的。
 *
 * 核心没把"当前发言人"塞进 ctx，但 `ctx.session.trigger` 就是**唤醒这次运行的那批消息**，
 * 里面带着真实发送者。所以：
 *   ① 候选 = 本次唤醒的消息 + 最近的非自己消息（都排掉"机器人自己的播报"）；
 *   ② 优先认"说了这句话"的那条：从模型传来的文本里抽数字/词，看哪条候选消息里有；
 *   ③ 认不出就退回最后一条候选。
 *
 * ⚠️ 2026-09-22 实测的坑：以前只按"文本前 12 个字包含"匹配，模型把玩家原话传成
 *    `@你 65@你（@我/提到我）` 这种带 @ 的脏文本时完全匹配不上 → 退化成"最后一条消息"，
 *    于是两个人先后猜的数被算成同一个人（群里显示"江边月下柳 猜 65"，其实 65 是别人说的）。
 */
function playerOf(ctx, hint = '') {
  const cands = [];
  const push = (m) => {
    if (!m || m.self) return;
    if (!m.senderId && !m.senderName) return;
    if (looksLikeOwnOutput(m.text)) return;              // 对方实例/自己的播报不算玩家
    cands.push(m);
  };
  try { (ctx?.session?.trigger || []).forEach(push); } catch { /* ignore */ }
  try { (ctx?.store?.recent?.(ctx.chatKey, { limit: 12, includeSelf: false }) || []).forEach(push); } catch { /* ignore */ }
  if (!cands.length) return null;

  const make = (m) => ({ id: String(m.senderId || ''), name: String(m.senderName || m.senderId || '') });
  const tokens = tokensOf(hint);
  if (tokens.length) {
    // 从新到旧找：命中越靠后的消息越可能是这一步的主人
    for (let i = cands.length - 1; i >= 0; i -= 1) {
      const t = String(cands[i].text || '');
      if (tokens.some((k) => t.includes(k))) return make(cands[i]);
    }
  }
  return make(cands[cands.length - 1]);
}

/** 从一段话里抽"可用来对号入座"的 token：数字，以及 ≥2 字的连续汉字。 */
function tokensOf(text) {
  const t = String(text || '')
    .replace(/\[CQ:[^\]]*\]/g, ' ')
    .replace(/@[^\s@]{0,20}/g, ' ')
    .replace(/[（(][^）)]*[）)]/g, ' ');
  const nums = t.match(/\d+/g) || [];
  const words = t.match(/[\u4e00-\u9fa5]{2,}/g) || [];
  return [...new Set([...nums, ...words])];
}

/**
 * 把结果发出去。默认由插件直接发（走发送队列：串行 / 限频 / 去重 / 留档），
 * 这样"判定结果"不会因为模型改口、漏说而丢失 —— 小游戏最忌讳这个。
 * announceInGroup=false 时改成把文本交给模型，让它自己组织。
 * @returns {boolean} 是否真的发出去了
 */
async function say(ctx, text) {
  const body = String(text || '').trim();
  if (!body) return false;
  if (cfg().announceInGroup === false) return false;     // 这次交给模型说
  try {
    await ctx.sender.sendTextBatch(ctx.chatKey, [body]);
    try {
      ctx.session?.sent?.push({ type: 'text', text: body, at: new Date().toLocaleTimeString('zh-CN', { hour12: false }) });
    } catch { /* 留档失败不影响已发出的消息 */ }
    return true;
  } catch {
    // 发不出去也不能把判定结果吞了：交给模型让它至少说一声
    return false;
  }
}

/**
 * 把历史里**旧的小游戏注入行**删掉。
 * 为什么需要：注入是追加到最后一条 user 消息末尾的一行，而一次运行会跑多轮、
 * 跨运行更会反复注入 —— 不清就会在上下文里堆成一片。
 * 只认我们自己那种"单行、首尾都是 ⟦小游戏⟧"的形态，群友原话里出现同样标记的概率可忽略。
 */
function stripInjection(messages) {
  const arr = Array.isArray(messages) ? messages : [];
  const re = new RegExp(`${MARK}[^\\n]*${MARK}`, 'g');
  for (const m of arr) {
    if (!m || m.role !== 'user') continue;
    if (typeof m.content === 'string') {
      if (m.content.includes(MARK)) m.content = m.content.replace(re, '').replace(/\n+$/, '');
      continue;
    }
    if (Array.isArray(m.content)) {
      for (const part of m.content) {
        if (part && typeof part.text === 'string' && part.text.includes(MARK)) {
          part.text = part.text.replace(re, '').replace(/\n+$/, '');
        }
      }
    }
  }
}

/** 把一行局面追加到最后一条 user 消息末尾（原地改，不改结构）。 */
function appendToLastUser(messages, lineText) {
  const arr = Array.isArray(messages) ? messages : [];
  const last = [...arr].reverse().find((m) => m && m.role === 'user');
  if (!last) return false;
  const suffix = `\n${lineText}`;
  if (Array.isArray(last.content)) {
    const texts = last.content.filter((p) => p && p.type === 'text');
    if (!texts.length) return false;
    const cur = String(texts[texts.length - 1].text || '');
    if (cur.includes(MARK)) return false;
    texts[texts.length - 1].text = `${cur}${suffix}`;
    return true;
  }
  if (typeof last.content !== 'string') return false;
  if (last.content.includes(MARK)) return false;
  last.content = `${last.content}${suffix}`;
  return true;
}

/**
 * 把模型回复正文里的汤底原文抹掉（L2）。
 * 整段都是汤底时直接把 content 置空 —— 这条正文就什么都不发了。
 */
function redactSecret(response, secret) {
  const msg = response?.message;
  if (!msg) return 0;
  let hits = 0;
  if (typeof msg.content === 'string') {
    const r = stripSecret(msg.content, secret);
    if (r.hits) {
      msg.content = (r.text.replace(/（略）/g, '').trim().length < 4) ? null : r.text;
      hits += r.hits;
    }
  } else if (Array.isArray(msg.content)) {
    for (const part of msg.content) {
      if (part && typeof part.text === 'string') {
        const r = stripSecret(part.text, secret);
        if (r.hits) { part.text = r.text; hits += r.hits; }
      }
    }
  }
  return hits;
}

// 测试出口（不参与运行时逻辑）
export const internals = {
  playerOf, tokensOf, appendToLastUser, stripInjection, listGames, DATA_DIR,
  revealGame, spoilerOf, redactSecret, leakedChunk, stripSecret
};
